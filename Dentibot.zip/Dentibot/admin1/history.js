// Firebase initialization and Firestore reference
const firebaseConfig = {
  apiKey: "AIzaSyAEU4nZ0oNOGGrySJLCdsaDnECozuBOK4M",
  authDomain: "conversation-a42a5.firebaseapp.com",
  projectId: "conversation-a42a5",
  storageBucket: "conversation-a42a5.appspot.com",
  messagingSenderId: "212723116270",
  appId: "1:212723116270:web:1b89309f5dacef3295ebff"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Function to fetch appointments and update sidebar
function fetchAppointmentsAndDisplayNames() {
  const patientList = document.getElementById('patientList');
  const appointmentsRef = db.collection('appointments');

  // Real-time listener for new appointments
  appointmentsRef.onSnapshot(snapshot => {
    snapshot.docChanges().forEach(change => {
      if (change.type === 'added') {
        const appointmentData = change.doc.data();
        const appointmentID = change.doc.id;

        const listItem = document.createElement('li');
        listItem.classList.add('patient-list-item');
        const link = document.createElement('a');
        link.href = "#";
        link.textContent = appointmentID;
        link.style.color = "black"; // Set the color to black
        link.style.textDecoration = "none"; // Remove underline
        link.style.fontSize = "18px"

        link.addEventListener('click', function () {
          updatePatientDetails(appointmentData);
          listItem.classList.add('clicked');
        });

        listItem.appendChild(link);
        patientList.appendChild(listItem);
      }
    });
  });
}

// Function to fetch appointments and update sidebar
function fetchAppointmentsAndDisplayNames() {
  const patientList = document.getElementById('patientList');
  const appointmentsRef = db.collection('appointments');

  // Create a map to store appointments grouped by patient name
  const appointmentsByPatient = new Map();

  // Real-time listener for new appointments
  appointmentsRef.onSnapshot(snapshot => {
    snapshot.docChanges().forEach(change => {
      if (change.type === 'added') {
        const appointmentData = change.doc.data();
        const appointmentID = change.doc.id;
        const patientName = appointmentData.Patient_Name || 'Unknown';

        // Check if there's already an entry for this patient
        if (appointmentsByPatient.has(patientName)) {
          appointmentsByPatient.get(patientName).push({ id: appointmentID, data: appointmentData });
        } else {
          appointmentsByPatient.set(patientName, [{ id: appointmentID, data: appointmentData }]);
        }
      }
    });

    // Clear the patient list
    patientList.innerHTML = '';

    // Iterate through appointments grouped by patient name
    appointmentsByPatient.forEach((appointments, patientName) => {
      const patientDetails = document.createElement('div');
      patientDetails.classList.add('patient-details');

      // Create an h3 element for the patient name
      const patientHeader = document.createElement('h3');
      patientHeader.textContent = patientName;
      patientHeader.addEventListener('click', function () {
        updatePatientDetails(appointments);
        // Update the h2 element with the clicked patient's name
        const patientDentalHistoryHeader = document.getElementById('patientHistory').querySelector('h2');
        patientDentalHistoryHeader.textContent = `${patientName} Dental History`;
      });
      patientHeader.style.cursor = 'pointer'; // Set cursor to pointer on hover


      // Append the patient header to the patient details container
      patientDetails.appendChild(patientHeader);

      // Add each appointment for the patient
      appointments.forEach(appointment => {
        const listItem = document.createElement('li');
        listItem.classList.add('patient-list-item');
        const link = document.createElement('a');
        link.href = "#";
        link.textContent = appointment.id;
        link.style.color = "black"; // Set the color to black
        link.style.textDecoration = "none"; // Remove underline
        link.style.fontSize = "18px";

        link.addEventListener('click', function () {
          updatePatientDetails(appointment.data);
          listItem.classList.add('clicked');
        });

        listItem.appendChild(link);
        patientDetails.appendChild(listItem);
      });

      patientList.appendChild(patientDetails);
    });
  });
}

// Function to update patient details based on selected appointment data
function updatePatientDetails(appointments) {
  const patientDetails = document.getElementById('patientDetails');
  patientDetails.innerHTML = ''; // Clear previous content

  if (Array.isArray(appointments)) {
    // Display details for multiple appointments
    appointments.forEach(appointment => {
      const appointmentData = appointment.data;
      displayAppointmentDetails(appointmentData, patientDetails);
    });
  } else {
    // Display details for a single appointment
    displayAppointmentDetails(appointments, patientDetails);
  }
}

// Function to display appointment details
function displayAppointmentDetails(appointmentData, patientDetails) {
  const fieldsMapping = {
    'Date': 'Date',
    'Reason of Appointment': 'Reason_of_Appointment',
    'Patient Name': 'Patient_Name',
    'Contact Number': 'Contact_Number',
    'Time of Appointment': 'Time_of_Appointment',
    'Status': 'Status'
  };

  // Display appointment details
  for (const field in fieldsMapping) {
    const fieldName = fieldsMapping[field];
    let fieldValue = appointmentData[fieldName];
    if (fieldName === 'Date' && fieldValue instanceof firebase.firestore.Timestamp) {
      fieldValue = fieldValue.toDate(); // Convert Firestore Timestamp to JavaScript Date object
      const dateOptions = { year: 'numeric', month: 'short', day: 'numeric' };
      const timeOptions = { hour: 'numeric', minute: '2-digit', hour12: true };
      fieldValue = fieldValue.toLocaleDateString('en-US', dateOptions) + ' ' + fieldValue.toLocaleTimeString('en-US', timeOptions); // Combine date and time
    } else if (fieldName === 'Time of Appointment' && fieldValue instanceof firebase.firestore.Timestamp) {
      const appointmentTime = new Date(fieldValue.seconds * 1000); // Convert Firestore Timestamp to JavaScript Date object
      const timeOptions = { hour: 'numeric', minute: '2-digit', hour12: true };
      fieldValue = appointmentTime.toLocaleTimeString('en-US', timeOptions); // Format time in 12-hour format
    }
    patientDetails.innerHTML += `<p><strong>${field}:</strong> ${fieldValue}</p>`;
  }

  // Add a horizontal rule to separate appointments
  patientDetails.innerHTML += '<hr>';
}




// Call the function to fetch appointments and display names
fetchAppointmentsAndDisplayNames();

// Function to filter patient list based on search query
function filterPatientList() {
  const searchInput = document.getElementById('search-input');
  const patientList = document.getElementById('patientList');
  const searchText = searchInput.value.toLowerCase(); // Convert search query to lowercase for case-insensitive matching

  // Filter patient list based on search query
  Array.from(patientList.children).forEach(patient => {
    const patientName = patient.textContent.toLowerCase(); // Get patient name from list item
    if (patientName.includes(searchText)) {
      patient.style.display = 'block'; // Show patient if their name matches the search query
    } else {
      patient.style.display = 'none'; // Hide patient if their name does not match the search query
    }
  });
}

// Event listener for search input
document.getElementById('search-input').addEventListener('input', filterPatientList);


// Add an event listener to the print button
document.getElementById('print-button').addEventListener('click', function() {
  // Check if any patient history has been clicked
  const patientDetails = document.getElementById('patientDetails');
  if (patientDetails.textContent.trim() === 'Click on a patient to view their history.') {
    // If no patient history has been clicked, show a pop-up alert
    alert('Please click on a patient history first to print.');
  } else {
    // If a patient history has been clicked, open the print page in a new window
    const printWindow = window.open('print-history.html', '_blank');
    printWindow.onload = function() {
      // Get the patient's name
      const patientName = document.getElementById('patientHistory').querySelector('h2').textContent;
      // Get the image source
      const imagePath = 'GC 2.png'; // Replace with the actual path to your image file
      // Populate the print page with patient's history content, name, and image
      let patientHistoryContent = `
        <img src="${imagePath}" alt="Image" style="width: 100%; max-width: 300px; display: block; margin: 0 auto;">
        <br><hr><br>
        <h2 style="font-size: 34px;">${patientName}</h2>
        <br><br>`; // Add <hr> below <h2>
      patientHistoryContent += patientDetails.innerHTML;
      printWindow.document.getElementById('printContent').innerHTML = patientHistoryContent;
      // Trigger the print dialog in the print page
      printWindow.print();
    };
  }
});






// Function to handle the back button click
function goBack() {
  // Implement your logic to go back. This could be navigating to a previous page or a specific state in your application.
  // For example, to go back to the previous page in the browser's history:
  window.history.back();
}

// Event listener for the back button
document.getElementById('back-button').addEventListener('click', goBack);