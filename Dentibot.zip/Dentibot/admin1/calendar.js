

const firebaseConfig = {
    apiKey: "AIzaSyAEU4nZ0oNOGGrySJLCdsaDnECozuBOK4M",
    authDomain: "conversation-a42a5.firebaseapp.com",
    projectId: "conversation-a42a5",
    storageBucket: "conversation-a42a5.appspot.com",
    messagingSenderId: "212723116270",
    appId: "1:212723116270:web:1b89309f5dacef3295ebff"
};

// Initialize Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

let currentYear, currentMonth, today;

async function getAppointmentsForMonth(year, month) {
    const startOfMonth = new Date(year, month, 1);
    const endOfMonth = new Date(year, month + 1, 0);

    let appointments = [];
    try {
        const querySnapshot = await db.collection("appointments")
            .where("Date", ">=", startOfMonth)
            .where("Date", "<=", endOfMonth)
            .get();
        querySnapshot.forEach(doc => {
            let appointmentData = doc.data();
            appointmentData.id = doc.id; // Store the document ID
            appointments.push(appointmentData);
        });
    } catch (error) {
        console.error("Error getting documents: ", error);
    }
    return appointments;
}


function createDayElement(day, appointments, year, month) {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    dayElement.style.position = 'relative'; // Needed for absolute positioning of the dots

    if (day !== null) {
        dayElement.innerText = day;

        // Create a Date object for the current day
        const dayDate = new Date(year, month, day);
        const todayDate = new Date();

        // Set to the start of the day for comparison
        todayDate.setHours(0, 0, 0, 0);

        // Store appointment IDs in the day element
        dayElement.appointmentIds = appointments.map(appointment => appointment.id);

        // Filter appointments for this specific day
        const dayAppointments = appointments.filter(appointment => {
            const appointmentDate = new Date(appointment.Date.seconds * 1000);
            return appointmentDate.getDate() === day;
        });

        // Add a dot for each appointment
        dayAppointments.forEach((appointment, index) => {
            const dot = document.createElement('span');
            dot.className = `appointment-dot dot-${appointment.id}`; // Include the appointment ID in the class
            dot.style.bottom = '5px';
            // Adjust the left position for each dot so they don't overlap
            dot.style.left = `${5 + (15 * index)}px`;

            // Check if the appointment is completed and set the dot color accordingly
            if (appointment.Status === 'Completed') {
                dot.style.backgroundColor = 'rgb(41, 248, 0)'; // Green color for completed appointments
            }

            dayElement.appendChild(dot);
        });

        // Attach the onclick event to display appointment details for all days
        dayElement.onclick = () => {
            highlightSelectedDay(dayElement, day);
            displayAppointmentDetails(day); // Display appointment details when clicked
        };

        if (dayDate < todayDate) {
            // If the day is in the past, change its appearance
            dayElement.classList.add('past-day'); // Add a class to style past days differently
        }
    }
    return dayElement;
}


function displayAppointmentIds(appointmentIds) {
    if (appointmentIds && appointmentIds.length > 0) {
        console.log("Appointment IDs for selected day:", appointmentIds);
    } else {
        console.log("No appointments for this day.");
    }
}



async function createCalendar(year, month) {
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    let firstDay = new Date(year, month, 1).getDay();
    firstDay = firstDay === 0 ? 6 : firstDay - 1;

    const calendar = document.getElementById('calendar');
    calendar.innerHTML = '';

    const appointments = await getAppointmentsForMonth(year, month);

    // Create empty slots for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
        const emptyDayElement = createDayElement(null, []);
        calendar.appendChild(emptyDayElement);
    }

    // Create actual days
    for (let i = 1; i <= daysInMonth; i++) {
        const dayElement = createDayElement(i, appointments, year, month);
        calendar.appendChild(dayElement);

        if (year === today.getFullYear() && month === today.getMonth() && i === today.getDate()) {
            highlightSelectedDay(dayElement, i);
        }
    }
}



function highlightSelectedDay(selectedDayElement, day) {
    // Remove highlight from all days
    document.querySelectorAll('.calendar-day').forEach(dayElement => {
        dayElement.classList.remove('selected-day');
    });

    // Highlight the selected day
    selectedDayElement.classList.add('selected-day');
    
    // Update the selected date display
    const selectedDateDiv = document.getElementById('selected-date');
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    selectedDateDiv.innerHTML = `<b>${months[currentMonth]} ${day}, ${currentYear}</b>`;

    // Set the selected day
    selectedDay = day;

    // Move the plus icon next to the year
    let addEventIcon = document.getElementById('add-event-icon');
    if (!addEventIcon) {
        addEventIcon = document.createElement('span');
        addEventIcon.id = 'add-event-icon';
        addEventIcon.className = 'fas fa-plus-circle';
    }
    selectedDateDiv.appendChild(addEventIcon);

    // Check if the selected day is in the past
    const selectedDate = new Date(currentYear, currentMonth, day);
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0); // Set to the start of the day for comparison

    if (selectedDate < todayDate) {
        // If the day is in the past, hide the plus icon
        addEventIcon.style.display = 'none';
    } else {
        // If the day is not in the past, show the plus icon
        addEventIcon.style.display = 'block';
        addEventIcon.onclick = function () {
            document.getElementById('event-modal').style.display = 'block';
        };
    }

    // Call to display the appointment details for the selected day
    displayAppointmentDetails(day);
}


// Function to display appointment details for a selected day
async function displayAppointmentDetails(day) {
    const selectedDate = new Date(currentYear, currentMonth, day);
    const appointments = await getAppointmentsForMonth(currentYear, currentMonth);
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0); // Set to the start of the day for comparison
    const dayAppointments = appointments.filter(appointment => {
        const appointmentDate = new Date(appointment.Date.seconds * 1000);
        return appointmentDate.getDate() === day;
    });

    // Sort appointments by time
    dayAppointments.sort((a, b) => {
        const timeA = convertTimeTo24HourFormat(a.Time_of_Appointment);
        const timeB = convertTimeTo24HourFormat(b.Time_of_Appointment);
        return timeA.localeCompare(timeB);
    });

    const dateDisplayDiv = document.getElementById('date-display');
    const selectedDateDiv = document.getElementById('selected-date');
    const formattedDate = selectedDate.toLocaleDateString('en-US', {
        weekday: 'short', // Short name of the day.
        month: 'short',   // Short name of the month.
        day: 'numeric',   // Numeric day of the month.
        year: 'numeric'   // Numeric year.
    });

    // Move the plus icon next to the year
    let addEventIcon = document.getElementById('add-event-icon');
    if (addEventIcon) {
        addEventIcon.remove(); // Remove it from its current location
    } else {
        addEventIcon = document.createElement('span');
        addEventIcon.id = 'add-event-icon';
        addEventIcon.className = 'fas fa-plus-circle';
        // Add any additional event listeners to the icon here
    }

    selectedDateDiv.innerHTML = `<b>${formattedDate}</b>`;
    selectedDateDiv.appendChild(addEventIcon);

    // Clear previous appointment details
    const existingDetails = document.getElementById('appointment-details');
    if (existingDetails) {
        existingDetails.remove();
    }

    // Create a container for new appointment details
    const detailsDiv = document.createElement('div');
    detailsDiv.id = 'appointment-details';

    // Iterate over sorted appointments and create elements for each
    dayAppointments.forEach(appointment => {
        const detailDiv = document.createElement('div');
        detailDiv.className = 'appointment-detail';

        // Patient Name and Edit Icon
        const patientNameSpan = document.createElement('span');
        patientNameSpan.innerHTML = `   <b>Patient:</b> <i>${appointment.Patient_Name}</i>`;
        patientNameSpan.className = 'patient-name';

        // Check if the appointment is completed and update the appearance
        if (appointment.Status === 'Completed') {
            detailDiv.style.opacity = '0.5';
            detailDiv.classList.add('disabled');
        }

        // Check Icon
        const checkIcon = document.createElement('i');
        checkIcon.className = 'fas fa-check check-icon';
        checkIcon.style.color = 'green'; // Optional: set the color of the check icon
        if (appointment.Status === 'Completed') {
            checkIcon.style.pointerEvents = 'none';
        } else {
            checkIcon.onclick = function () {
                confirmAppointmentCompletion(appointment.id, detailDiv);
            };
        }
        detailDiv.appendChild(checkIcon);

        // Append the check icon to the patient name span
        patientNameSpan.appendChild(checkIcon);

        const editIcon = document.createElement('i');
        editIcon.className = 'fas fa-pen edit-icon';
        editIcon.onclick = function () {
            openEditModal(appointment);
        };

        // Reason and Delete Icon
        const reasonSpan = document.createElement('span');
        reasonSpan.innerHTML = `<br><b>Reason:</b> <i>${appointment.Reason_of_Appointment}</i>`;
        reasonSpan.className = 'appointment-reason';

        const deleteIcon = document.createElement('i');
        deleteIcon.className = 'fas fa-trash delete-icon';
        deleteIcon.dataset.appointmentId = appointment.id; // Store the appointment ID in the icon
        deleteIcon.onclick = function () {
            confirmDeletion(appointment.id); // Call the confirm deletion function
        };

        // Time of Appointment
        const timeSpan = document.createElement('span');
        timeSpan.innerHTML = `<br><b>Time:</b> <i>${appointment.Time_of_Appointment}</i>`;
        timeSpan.className = 'appointment-time';

        // Contact Number
        const contactSpan = document.createElement('span');
        contactSpan.innerHTML = `<br><b>Contact:</b> <i>${appointment.Contact_Number}</i>`;
        contactSpan.className = 'appointment-contact';

        // If the selected day is in the past, disable the check, edit, and delete icons
        if (selectedDate < todayDate) {
            checkIcon.style.display = 'none'; // Hide the check icon
            editIcon.style.display = 'none'; // Hide the edit icon
            deleteIcon.style.display = 'none'; // Hide the delete icon
        } else {
            // Attach onclick events for future days
            checkIcon.onclick = function () {
                confirmAppointmentCompletion(appointment.id, detailDiv);
            };
            editIcon.onclick = function () {
                openEditModal(appointment);
            };
            deleteIcon.onclick = function () {
                confirmDeletion(appointment.id); // Call the confirm deletion function
            };
        }

        // Append icons to the respective spans
        timeSpan.appendChild(editIcon);
        contactSpan.appendChild(deleteIcon);

        // Append all elements to the detail div
        detailDiv.appendChild(patientNameSpan);
        detailDiv.appendChild(reasonSpan);
        detailDiv.appendChild(timeSpan);
        detailDiv.appendChild(contactSpan);

        detailsDiv.appendChild(detailDiv);
    });

    dateDisplayDiv.appendChild(detailsDiv);
}

function convertTimeTo24HourFormat(time12h) {
    const [time, modifier] = time12h.split(' ');
    let [hours, minutes] = time.split(':');
    if (hours === '12') {
        hours = '00';
    }
    if (modifier === 'PM') {
        hours = parseInt(hours, 10) + 12;
    }
    return `${hours}:${minutes}`;
}

// New function to confirm appointment completion
async function confirmAppointmentCompletion(appointmentId, detailElement) {
    const confirmation = confirm("Are you sure this appointment is done?");
    if (confirmation) {
        // User clicked 'Yes', update the appointment's appearance
        detailElement.style.opacity = '0.5';
        detailElement.classList.add('disabled');

        // Disable the check, edit, and delete icons
        const checkIcon = detailElement.querySelector('.check-icon');
        const editIcon = detailElement.querySelector('.edit-icon');
        const deleteIcon = detailElement.querySelector('.delete-icon');
        if (checkIcon) checkIcon.style.pointerEvents = 'none';
        if (editIcon) editIcon.style.pointerEvents = 'none';
        if (deleteIcon) deleteIcon.style.pointerEvents = 'none';

        // Update the appointment status in the database
        try {
            const docRef = db.collection("appointments").doc(appointmentId);
            await docRef.update({
                Status: 'Completed'
            });
            console.log("Appointment marked as completed with ID: ", appointmentId);

            // Find the associated dot and change its color to green
            const dots = document.querySelectorAll(`.dot-${appointmentId}`);
            dots.forEach(dot => {
                dot.style.backgroundColor = 'rgb(41, 248, 0)';
            });
        } catch (e) {
            console.error("Error updating document: ", e);
        }
    } else {
        // User clicked 'Cancel'
        console.log("Appointment completion canceled.");
    }
}



function confirmDeletion(appointmentId) {
    // Create the confirmation dialog
    const confirmation = confirm("Are you sure you want to delete this?");
    if (confirmation) {
        // User clicked 'Yes'
        deleteAppointment(appointmentId);
    } else {
        // User clicked 'Cancel'
        console.log("Deletion canceled.");
    }
}

async function deleteAppointment(appointmentId) {
    try {
        await db.collection("appointments").doc(appointmentId).delete();
        console.log(`Appointment with ID: ${appointmentId} has been deleted.`);
        createCalendar(currentYear, currentMonth); // Refresh the calendar
    } catch (error) {
        console.error("Error removing document: ", error);
    }
}

function openEditModal(appointment) {
    // Populate the form with the appointment's current details
    document.getElementById('edit-appointment-id').value = appointment.id;
    document.getElementById('edit-patient-name').value = appointment.Patient_Name;
    document.getElementById('edit-reason').value = appointment.Reason_of_Appointment;
    document.getElementById('edit-event-time').value = convertTo12HourFormat(appointment.Time_of_Appointment); // Assuming the time is stored in 12-hour format
    document.getElementById('edit-contact-number').value = appointment.Contact_Number;

    // Display the modal
    document.getElementById('edit-event-modal').style.display = 'block';
}

document.getElementById('edit-event-form').onsubmit = async function (event) {
    event.preventDefault();

    // Get the updated details from the form
    const appointmentId = document.getElementById('edit-appointment-id').value;
    const patientName = document.getElementById('edit-patient-name').value;
    const reason = document.getElementById('edit-reason').value;
    const contactNumber = document.getElementById('edit-contact-number').value;
    let eventTime = document.getElementById('edit-event-time').value;

    eventTime = convertTo12HourFormat(eventTime); // Convert back to 12-hour format if needed

    try {
        // Update the appointment in Firestore
        const docRef = db.collection("appointments").doc(appointmentId);
        await docRef.update({
            Patient_Name: patientName,
            Reason_of_Appointment: reason,
            Time_of_Appointment: eventTime,
            Contact_Number: contactNumber
        });
        console.log("Document successfully updated with ID: ", appointmentId);

        // Close the modal and refresh the calendar
        document.getElementById('edit-event-modal').style.display = 'none';
        createCalendar(currentYear, currentMonth);
    } catch (e) {
        console.error("Error updating document: ", e);
    }
};



function updateNavBar(year) {
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const currentYearDiv = document.getElementById('current-year');
    currentYearDiv.innerHTML = year;

    const monthList = document.getElementById('month-list');
    monthList.innerHTML = '';
    months.forEach((month, index) => {
        const monthItem = document.createElement('li');
        monthItem.innerText = month;
        monthItem.onclick = () => {
            setMonth(index);
            highlightSelectedMonth(monthItem);
        };
        monthList.appendChild(monthItem);
    });
}

function highlightSelectedMonth(selectedMonthItem) {
    // Remove highlight from all months
    document.querySelectorAll('#month-list li').forEach(monthItem => {
        monthItem.classList.remove('selected-month');
    });

    // Highlight the selected month
    if (selectedMonthItem) {
        selectedMonthItem.classList.add('selected-month');
    }
}


function setMonth(month) {
    currentMonth = month;
    createCalendar(currentYear, currentMonth);
    updateCalendarHeader(currentYear, currentMonth);

    // Highlight the selected month
    const monthListItems = document.querySelectorAll('#month-list li');
    if (monthListItems && monthListItems.length > currentMonth) {
        highlightSelectedMonth(monthListItems[currentMonth]);
    }
}


function changeYear(offset) {
    currentYear += offset;
    updateNavBar(currentYear);
    createCalendar(currentYear, currentMonth);
    updateCalendarHeader(currentYear, currentMonth);
}

function initCalendar() {
    today = new Date();
    currentYear = today.getFullYear();
    currentMonth = today.getMonth();

    document.getElementById('prev-year').onclick = () => changeYear(-1);
    document.getElementById('next-year').onclick = () => changeYear(1);

    updateNavBar(currentYear);
    createCalendar(currentYear, currentMonth);
    updateCalendarHeader(currentYear, currentMonth);

    // Highlight the current month in the navigation bar
    const monthListItems = document.querySelectorAll('#month-list li');
    if (monthListItems && monthListItems.length > currentMonth) {
        highlightSelectedMonth(monthListItems[currentMonth]);
    }

    // Event listener for the add event icon
    document.getElementById('add-event-icon').onclick = function () {
        document.getElementById('event-modal').style.display = 'block';
    };

    // Close modal when the close button is clicked
    document.querySelector('.close-button').onclick = function () {
        document.getElementById('event-modal').style.display = 'none';
    };

    // Close edit modal when the close button is clicked
    document.querySelector('#edit-event-modal .close-button').onclick = function () {
        document.getElementById('edit-event-modal').style.display = 'none';
    };

    // Handle form submission
    document.getElementById('event-form').onsubmit = function (event) {
        event.preventDefault();
        // Process form data here
        // Example: console.log(document.getElementById('patient-name').value);
        document.getElementById('event-modal').style.display = 'none';
    };
}

function updateCalendarHeader(year, month) {
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const calendarHeader = document.getElementById('calendar-header');
    calendarHeader.innerHTML = `<b>${months[month]} ${year}</b>`;
}

window.onload = initCalendar;

function convertTo12HourFormat(time24) {
    const [hours, minutes] = time24.split(':');
    const hoursInt = parseInt(hours, 10);
    const suffix = hoursInt >= 12 ? 'PM' : 'AM';
    const hours12 = ((hoursInt + 11) % 12 + 1);
    return `${hours12}:${minutes} ${suffix}`;
}

let selectedDay = null;

document.getElementById('event-modal').onsubmit = async function (event) {
    event.preventDefault();

    const patientName = document.getElementById('patient-name').value;
    const reason = document.getElementById('reason').value;
    const contactNumber = document.getElementById('contact-number').value;
    let eventTime = document.getElementById('event-time').value;
    const now = new Date();
    const selectedDate = new Date(currentYear, currentMonth, selectedDay, now.getHours(), now.getMinutes());
    const appointmentId = `${patientName}-${now.getTime()}`;

    eventTime = convertTo12HourFormat(eventTime);

    try {
        const docRef = db.collection("appointments").doc(appointmentId);
        await docRef.set({
            Patient_Name: patientName,
            Reason_of_Appointment: reason,
            Time_of_Appointment: eventTime,
            Contact_Number: contactNumber,
            Date: selectedDate,
            Status: 'Pending' // Default status for new appointments
        });
        console.log("Document successfully written with ID: ", appointmentId); 
    } catch (e) {
        console.error("Error adding document: ", e);
    }

    document.getElementById('event-modal').style.display = 'none';
    createCalendar(currentYear, currentMonth); // Refresh the calendar to show the new appointment
};


// Function to handle the back button click
function goBack() {
    // Implement your logic to go back. This could be navigating to a previous page or a specific state in your application.
    // For example, to go back to the previous page in the browser's history:
    window.history.back();
}

// Event listener for the back button
document.getElementById('back-button').addEventListener('click', goBack);

// Call this function where you need to navigate back
// goBack();

window.onload = initCalendar;
