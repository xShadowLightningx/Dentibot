document.addEventListener('DOMContentLoaded', function() {
  // Function to set the visit date to today's date
  function setTodaysDate() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    const yyyy = today.getFullYear();
    document.getElementById('visit-date').value = yyyy + '-' + mm + '-' + dd;
  }

  // Set the date when the page loads
  setTodaysDate();

  // Function to handle the back button click
  function goBack() {
    window.history.back();
  }

  // Event listener for the back button
  document.getElementById('back-button').addEventListener('click', goBack);

  // Update the date at midnight every day
  const now = new Date();
  const millisTillMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 24, 0, 0, 0) - now;
  setTimeout(function() {
    setTodaysDate();
    setInterval(setTodaysDate, 24 * 60 * 60 * 1000); // Update the date every 24 hours
  }, millisTillMidnight);

  // Function to check if the form and additional sections are fully filled out
  function isFormComplete() {
    const form = document.getElementById('patient-form');
    const description = document.getElementById('description').value.trim();
    const licNo = document.getElementById('lic-no').value.trim();
    const tinNo = document.getElementById('tin-no').value.trim();
    const ptrNo = document.getElementById('ptr-no').value.trim();
    const dentistName = document.getElementById('dentist-name').value.trim();

    // Check if the form and all additional fields are filled out
    return form.checkValidity() && description && licNo && tinNo && ptrNo && dentistName;
  }

  // Function to download the receipt as a PDF
  function downloadReceipt() {
    if (!isFormComplete()) {
      alert("Please fill out all required fields before downloading the receipt.");
      return;
    }
    const element = document.querySelector('.receipt-container');
    const opt = {
      margin:       [0.5, 0.5, 0.5, 0.5], // Top, Left, Bottom, Right in inches
      filename:     'Prescription.pdf',
      image:        { type: 'jpeg', quality: 0.98 },
      html2canvas:  { scale: 2 },
      jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
    };
  
    html2pdf().from(element).set(opt).save();
  }
  

  // Event listener for the download button
  document.getElementById('download-button').addEventListener('click', downloadReceipt);
});
