import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getFirestore, collection, onSnapshot, addDoc, getDocs, doc, getDoc, setDoc, query, where, orderBy } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-database.js";
import { serverTimestamp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-firestore.js";
import { signOut } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";
 
 
const firebaseConfig = { 
    apiKey: "AIzaSyAEU4nZ0oNOGGrySJLCdsaDnECozuBOK4M",
    authDomain: "conversation-a42a5.firebaseapp.com",
    projectId: "conversation-a42a5",
    storageBucket: "conversation-a42a5.appspot.com",
    messagingSenderId: "212723116270", 
    appId: "1:212723116270:web:1b89309f5dacef3295ebff"
  };

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

let currentAdminId = null;
let currentAdminEmail = null;

const adminChatMessages = document.getElementById('adminChatMessages');
const adminInput = document.getElementById('adminInput');
const logoutButton = document.getElementById('logoutButton');
const usersList = document.getElementById('usersList');
const personNameInput = document.getElementById('personName');


personNameInput.addEventListener('input', filterUsers);

// Function to set admin online status using Firestore
function setAdminOnlineStatus(isOnline) {
    if (!currentAdminId) return;

    const adminStatusDoc = doc(db, 'adminStatus', currentAdminId);
    setDoc(adminStatusDoc, { isOnline: isOnline });
}

// Listen for authentication state changes
onAuthStateChanged(auth, (user) => {
    if (user) {
        // User is signed in
        currentAdminId = user.uid;
        currentAdminEmail = user.email;
        console.log("Admin currently logged in with ID:", currentAdminId, "Email:", currentAdminEmail);
        setAdminOnlineStatus(true);
    } else {
        // No user is signed in
        console.log("No admin is currently logged in.");
        currentAdminId = null;
        currentAdminEmail = null;

        if (currentAdminId) {
            setAdminOnlineStatus(false);
        }
    }
});

async function getUsernameByUserId(userId) {

    if (!userId) {
        console.error("Invalid userId provided");
        return null;
    }

    try {
        const db = getDatabase(app); // Use the already initialized app instance
        const usernameRef = ref(db, 'users/' + userId + '/username');
        const snapshot = await get(usernameRef);
        if (snapshot.exists()) {
            return snapshot.val();
        } else {
            console.error(`No document for user ID: ${userId}`);
            return null;
        }
    } catch (error) {
        console.error("Error fetching username:", error);
        return null;
    }
}

// Function to update the chat display and auto-scroll to the latest message
function updateChatDisplay(newMessageHtml) {
    adminChatMessages.innerHTML += newMessageHtml;
    adminChatMessages.scrollTop = adminChatMessages.scrollHeight;
}

// Listen for real-time chat messages in Firestore
function listenForMessages() {
    const messagesCollection = collection(db, "realtimeChat");
    onSnapshot(messagesCollection, async snapshot => {
        const selectedUserElement = document.querySelector('#usersList .list-group-item.active');
        const selectedUserId = selectedUserElement ? selectedUserElement.dataset.userId : null;

        for (const change of snapshot.docChanges()) {
            if (change.type === "added") {
                const data = change.doc.data();
                const username = await getUsernameByUserId(data.userId);
                let newMessageHtml = '';

                // Check if the user ID is already in the list
                if (!document.querySelector(`#usersList [data-user-id="${data.userId}"]`)) {
                    const userElement = document.createElement('li');
                    userElement.className = 'list-group-item';
                    userElement.textContent = `${username}`;
                    userElement.dataset.userId = data.userId;

                    userElement.addEventListener('click', function() {
                        // Highlight the selected user
                        document.querySelectorAll('#usersList .list-group-item').forEach(item => {
                          item.classList.remove('active');
                        });
                        userElement.classList.add('active');
                      
                        // Clear the chat window and load the chat history for the selected user
                        clearAdminChat(); // Clear the chat when selecting a user
                        loadChatHistory(data.userId);
                      });
                      

                    document.getElementById('usersList').appendChild(userElement);
                }

                // Only display the message if the selected user matches the message's user
                if (selectedUserId === data.userId) {
                    const timestampString = formatTimestamp(data.timestamp);
                    if (data.sender === 'user') {
                        newMessageHtml = `<div class="bot-message"><b>${username}</b> (${timestampString}):<br>${data.message}</div>`;
                    } else if (data.sender === 'admin') {
                        newMessageHtml = `<div class="user-message"> (${timestampString}):<br>${data.message}</div>`;
                    }
                    updateChatDisplay(newMessageHtml);
                }
            }
        }
    });
}

function formatTimestamp(timestamp) {
    if (!timestamp) {
        // If timestamp is not available, display a placeholder or the current time
        return formatTimestamp(new Date());
    }

    let date;
    if (timestamp instanceof Date) {
        date = timestamp;
    } else if (timestamp.seconds) {
        date = new Date(timestamp.seconds * 1000);
    } else {
        return '';
    }

    // Format the date to include day, date, and time
    return date.toLocaleDateString('en-US', {
        weekday: 'short', // e.g., "Mon"
        year: 'numeric',
        month: 'short', // e.g., "Jan"
        day: 'numeric', // e.g., "31"
        hour: '2-digit', // e.g., "11"
        minute: '2-digit' // e.g., "59"
    });
}




function clearAdminChat() {
    adminChatMessages.innerHTML = '';
  }
  
// Send admin message to Firestore
function sendMessage() {
    const message = adminInput.value.trim();
    const selectedUserElement = document.querySelector('#usersList .list-group-item.active');
    const selectedUserId = selectedUserElement ? selectedUserElement.dataset.userId : null;

    if (message && selectedUserId) {
        addDoc(collection(db, "realtimeChat"), {
            sender: 'admin',
            message: message,
            timestamp: serverTimestamp(),
            userId: selectedUserId,
            adminId: currentAdminId
        });
        adminInput.value = '';
    } else {
        console.log("Message is empty or no user is selected. Not sending.");
    }
}



async function loadChatHistory(userId) {
    const messagesCollection = collection(db, "realtimeChat");
    const userMessagesQuery = query(messagesCollection, where("userId", "==", userId), orderBy("timestamp", "asc"));
    const snapshot = await getDocs(userMessagesQuery);

    const username = await getUsernameByUserId(userId); // Fetch the username for the given userId

    adminChatMessages.innerHTML = ''; // Clear the chat window

    let lastDate = null;
    snapshot.forEach(doc => {
        const messageData = doc.data();
        const messageDate = messageData.timestamp.toDate();
        const dateString = messageDate.toLocaleDateString();
    
        // Check if the date has changed since the last message
        if (lastDate !== dateString) {
            adminChatMessages.innerHTML += `<div class="date-header">${formatDateHeader(messageDate)}</div>`;
            lastDate = dateString;
        }
    
        // Append message with line break after sender and timestamp
        const timestampString = formatTimestamp(messageData.timestamp);
        if (messageData.sender === 'user') {
            adminChatMessages.innerHTML += `<div class="bot-message"><b>${username}</b> (${timestampString}):<br>${messageData.message}</div>`;
        } else if (messageData.sender === 'admin') {
            adminChatMessages.innerHTML += `<div class="user-message"> (${timestampString}):<br>${messageData.message}</div>`;
        }
    });
    
}

function formatDateHeader(date) {
    return date.toLocaleDateString('en-US', { weekday: 'long' }); // E.g., "Monday"
}


function filterUsers() {
    const searchTerm = personNameInput.value.toLowerCase().trim();

    // Get all user list items
    const userItems = document.querySelectorAll('#usersList .list-group-item');

    userItems.forEach(item => {
        const userName = item.textContent.toLowerCase();

        // Check if the user name includes the search term
        if (userName.includes(searchTerm)) {
            item.style.display = ''; // Show the user
        } else {
            item.style.display = 'none'; // Hide the user
        }
    });
}


logoutButton.addEventListener('click', function() {
    const userConfirmed = confirm("Are you sure you want to log out?");

    if (userConfirmed) {
        signOut(auth).then(() => {
            window.location.href = 'index.html';
        }).catch((error) => {
            console.error("Error signing out: ", error);
        });
    } else {
        console.log("Logout cancelled.");
    }
    setAdminOnlineStatus(false);
});


document.getElementById('adminSendMessage').addEventListener('click', sendMessage);
adminInput.addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
});

// Start listening for messages when the page loads
listenForMessages();


// Add this function to your adminlanding.js

function updateAdminOfflineStatus() {
    if (!currentAdminId) return;

    const adminStatusDoc = doc(db, 'adminStatus', currentAdminId);
    setDoc(adminStatusDoc, { isOnline: false })
        .then(() => console.log("Admin status updated to offline"))
        .catch(error => console.error("Error updating admin status:", error));
}

// Add this event listener
window.addEventListener('beforeunload', (event) => {
    updateAdminOfflineStatus();
});

// Function to navigate to a new window or URL
function navigateTo(url) {
    window.location.href = url;
}

// Event listeners for buttons
document.getElementById('appointment').addEventListener('click', () => navigateTo('calendar.html'));
document.getElementById('history').addEventListener('click', () => navigateTo('history.html'));
document.getElementById('prescription').addEventListener('click', () => navigateTo('receipt.html'));
document.getElementById('payment').addEventListener('click', () => navigateTo('payment.html'));