// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.4/firebase-app.js";
import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/9.6.4/firebase-database.js";

// Firebase configuration object
const firebaseConfig = {
    apiKey: "AIzaSyAEU4nZ0oNOGGrySJLCdsaDnECozuBOK4M",
    authDomain: "conversation-a42a5.firebaseapp.com",
    projectId: "conversation-a42a5",
    storageBucket: "conversation-a42a5.appspot.com",
    messagingSenderId: "212723116270",
    appId: "1:212723116270:web:1b89309f5dacef3295ebff"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Reference to the 'admins' and 'users' nodes in the Realtime Database
const adminsRef = ref(db, "admins");
const usersRef = ref(db, "users");

// Function to display or hide admin info
function toggleAdminInfo(admin) {
    const adminUsername = document.getElementById("adminUsername");
    const adminPassword = document.getElementById("adminPassword");
    const adminEmail = document.getElementById("adminEmail");
    const adminLastLogin = document.getElementById("adminLastLogin");
    const adminInfo = document.getElementById("adminInfo");

    // Check if the clicked admin is the same as the currently displayed admin
    if (adminEmail.textContent === admin.email && adminInfo.style.display === "inline-block") {
        adminInfo.style.display = "none"; // Hide admin info
    } else {
        // Update admin info
        adminEmail.textContent = admin.email;
        adminUsername.textContent = admin.username;
        adminPassword.textContent = admin.password;
        adminLastLogin.textContent = admin.last_login;
        adminInfo.style.display = "inline-block"; // Show admin info
    }
    localStorage.setItem('adminInfo', JSON.stringify({
        display: adminInfo.style.display,
        data: admin
    }));
}

// Function to display or hide user info
function toggleUserInfo(user) {
    const userUsername = document.getElementById("userUsername");
    const userPassword = document.getElementById("userPassword");
    const userEmail = document.getElementById("userEmail");
    const userLastLogin = document.getElementById("userLastLogin");
    const userInfo = document.getElementById("userInfo");

    // Check if the clicked user is the same as the currently displayed user
    if (userEmail.textContent === user.email && userInfo.style.display === "inline-block") {
        userInfo.style.display = "none"; // Hide user info
    } else {
        // Update user info
        userEmail.textContent = user.email; 
        userUsername.textContent = user.username;
        userPassword.textContent = user.password;
        userLastLogin.textContent = user.last_login;
        userInfo.style.display = "inline-block"; // Show user info
    }
    localStorage.setItem('userInfo', JSON.stringify({
        display: userInfo.style.display,
        data: user
    }));
}

// Fetch data for Admins
const adminList = document.getElementById("adminList");
fetchData(adminsRef, adminList, toggleAdminInfo);

// Fetch data for Users
const userList = document.getElementById("userList");
fetchData(usersRef, userList, toggleUserInfo);

function loadAdminInfo() {
    const savedState = localStorage.getItem('adminInfo');
    if (savedState) {
        const { display, data } = JSON.parse(savedState);
        const adminInfo = document.getElementById("adminInfo");
        adminInfo.style.display = display;
        if (display === 'inline-block') {
            toggleAdminInfo(data);
        }
    }
}

function loadUserInfo() {
    const savedState = localStorage.getItem('userInfo');
    if (savedState) {
        const { display, data } = JSON.parse(savedState);
        const userInfo = document.getElementById("userInfo");
        userInfo.style.display = display;
        if (display === 'inline-block') {
            toggleUserInfo(data);
        }
    }
}

window.onload = () => {
    loadAdminInfo();
    loadUserInfo();
};


// Function to create a clickable email link
function createClickableEmailLink(item, onClickHandler) {
    const emailLink = document.createElement("a");
    emailLink.textContent = item.email;
    emailLink.href = "#"; // Add a dummy href to make it clickable

    // Attach a click event handler to the email link
    emailLink.addEventListener("click", () => {
        onClickHandler(item);
    });

    return emailLink;
}

// Function to fetch and display data in the admin and user panels
async function fetchData(databaseRef, listElement, onClickHandler) {
    try {
        const snapshot = await get(databaseRef);
        const data = snapshot.val();

        listElement.innerHTML = ''; // Clear the list before populating it

        for (const key in data) {
            if (Object.hasOwnProperty.call(data, key)) {
                const item = data[key];
                const listItem = document.createElement("li");

                const emailLink = createClickableEmailLink(item, onClickHandler);
                listItem.appendChild(emailLink);
                listElement.appendChild(listItem);
            }
        }
    } catch (error) {
        console.error("Error fetching data:", error);
    }
}


// Function to filter accounts based on the search input
function filterAccounts(searchText, dataList) {
    const listItems = dataList.querySelectorAll('li');

    listItems.forEach((item) => {
        const email = item.textContent.toLowerCase();
        if (email.includes(searchText.toLowerCase())) {
            item.style.display = 'block'; // Show matching item
        } else {
            item.style.display = 'none'; // Hide non-matching item
        }
    });
}

// Add an event listener to the search input
const searchInput = document.getElementById('searchInput');
searchInput.addEventListener('input', () => {
    const adminList = document.getElementById('adminList');
    const userList = document.getElementById('userList');

    // Filter admin and user lists based on the search input
    filterAccounts(searchInput.value, adminList);
    filterAccounts(searchInput.value, userList);
});
