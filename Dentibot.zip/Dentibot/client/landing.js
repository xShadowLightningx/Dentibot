
// Import core Firebase app
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-app.js";

// Import Firestore service 
import { getFirestore, collection, addDoc, getDocs, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-firestore.js";

import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-auth.js";

import { deleteDoc } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-firestore.js";

import { setPersistence, browserLocalPersistence } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-auth.js";

import { getDatabase, ref, get } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-database.js";

import { query, where, orderBy, onSnapshot } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-firestore.js";

import { serverTimestamp } from "https://www.gstatic.com/firebasejs/9.1.1/firebase-firestore.js";


document.addEventListener("DOMContentLoaded", function () {

  const firebaseConfig = {
    apiKey: "AIzaSyAEU4nZ0oNOGGrySJLCdsaDnECozuBOK4M",
    authDomain: "conversation-a42a5.firebaseapp.com",
    projectId: "conversation-a42a5",
    storageBucket: "conversation-a42a5.appspot.com",
    messagingSenderId: "212723116270",
    appId: "1:212723116270:web:1b89309f5dacef3295ebff",
    measurementId: "G-XKRF4XL71Y"
  };

  const app = initializeApp(firebaseConfig);
  const db = getFirestore(app);  // Initialize Firestore
  const auth = getAuth();



  function logout() {
    const confirmation = confirm("Are you sure you want to log out?");
  
    if (confirmation) {
      getAuth().signOut().then(() => {
        // Sign-out successful.
        window.location.href = "index.html"; // Replace with the path to your login page
      }).catch((error) => {
        // An error happened during sign out.
        console.error("Error signing out:", error);
      });
    } else {
      console.log("Logout cancelled.");
    }
  }

  // Attach the logout function to the button
  document.getElementById('logoutButton').addEventListener('click', logout);



  setPersistence(auth, browserLocalPersistence)
    .then(() => {
      console.log("Auth state will now persist even if the browser is closed.");
    })
    .catch((error) => {
      // Handle Errors here.
      console.error("Error setting persistence:", error);
    });


// ... (previous code) ...



  const realtimeChatContainer = document.getElementById('realtimeChatContainer');
  const realtimeChatMessages = document.getElementById('realtimeChatMessages');
  const realtimeUserInput = document.getElementById('realtimeUserInput');
  const sendRealtimeMessageBtn = document.getElementById('sendRealtimeMessage');
  const switchToRealtimeChatBtn = document.getElementById('switchToRealtimeChat');
  const switchToChatbotBtn = document.getElementById('switchToChatbot');




  // Send messages from the real-time chat interface
  sendRealtimeMessageBtn.addEventListener('click', sendRealtimeMessage);

  realtimeUserInput.addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
      sendRealtimeMessage();
    }
  });
  

  function formatTimestamp(timestamp) {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }  
  
  async function sendRealtimeMessage() {
    const message = realtimeUserInput.value.trim();
    if (message) {
        const user = auth.currentUser;
        if (user) {
            const messageData = {
                sender: 'user',
                message: message,
                timestamp: serverTimestamp(), // Firebase server timestamp
                userId: user.uid
            };

            await addDoc(collection(db, "realtimeChat"), messageData);

            const timestamp = new Date(); // Local timestamp for immediate display
            realtimeChatMessages.innerHTML += `<div class="user-message"><span class="timestamp">${formatTimestamp(timestamp)}</span> <div>${message}</div></div>`;
            realtimeUserInput.value = '';
        } else {
            console.error("User is not signed in.");
        }
    } else {
        console.log("Message is empty. Not sending.");
    }
}


  function checkAdminOnlineStatus() {
    const adminStatusCollection = collection(db, 'adminStatus');
    onSnapshot(adminStatusCollection, (snapshot) => {
        const isAnyAdminOnline = snapshot.docs.some(doc => doc.data().isOnline);

        const realtimeChatMessages = document.getElementById('realtimeChatMessages');
        const messageInput = document.getElementById('realtimeUserInput'); // Your message input field ID
        const sendMessageButton = document.getElementById('sendRealtimeMessage'); // Your send button ID

        // Clear previous system messages
        realtimeChatMessages.querySelectorAll('.system-message').forEach(msg => msg.remove());

        let systemMessage = document.createElement('div');
        systemMessage.className = 'system-message';

        if (!isAnyAdminOnline) {
            // Display message that no doctor is in and disable chat input and send button
            systemMessage.textContent = 'The Doctor is not in.';
            systemMessage.style.backgroundColor = 'red';
            messageInput.disabled = true;
            sendMessageButton.disabled = true;
        } else {
            // Display message that doctor is in, enable chat input and send button, and remove message after 2 seconds
            systemMessage.textContent = 'The Doctor is now in.';
            systemMessage.style.backgroundColor = 'green';
            messageInput.disabled = false;
            sendMessageButton.disabled = false;
            setTimeout(() => {
                systemMessage.remove();
            }, 2000);
        }

        realtimeChatMessages.appendChild(systemMessage);
    });
}




document.getElementById('switchToRealtimeChat').addEventListener('click', function() {
    // Switch to real-time chat UI
    // ... your existing code to switch UI ...

    // Check admin online status and update message
    checkAdminOnlineStatus();
});




function listenForAdminMessages() {
  const messagesCollection = collection(db, "realtimeChat");
  const q = query(messagesCollection, where("sender", "==", "admin"), orderBy("timestamp", "asc"));

  onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
          if (change.type === "added") {
              const data = change.doc.data();
              const timestamp = data.timestamp ? new Date(data.timestamp.toDate()) : new Date();
              realtimeChatMessages.innerHTML += `<div class="admin-message"><span class="timestamp"></span><b>Dr. Alex: </b> ${formatTimestamp(timestamp)} <div>${data.message}</div></div>`;
          }
      });
  });
}


  async function loadPreviousMessages() {
    const messagesCollection = collection(db, "realtimeChat");
    const q = query(messagesCollection, orderBy("timestamp", "asc"));
    const snapshot = await getDocs(q);

    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.sender === 'user') {
        realtimeChatMessages.innerHTML += `<div class="user-message">${data.message}</div>`;
      } else {
        realtimeChatMessages.innerHTML += `<div class="admin-message"><b>Dr. Alex:</b> ${data.message}</div>`;
      }
    });
  }

  

    onAuthStateChanged(auth, async (user) => {
      if (user) {
        console.log("User signed in, UID:", user.uid);
        try {
          const username = await getUsernameByUserId(user.uid);
          console.log("Username fetched:", username);
          // Additional code to use the username
        } catch (error) {
          console.error("Error fetching username:", error);
        }
      } else {
        console.log("No user is signed in.");
      }
    });
  
  
  
  async function getUsernameByUserId(userId) {
    const db = getDatabase();
    const usernameRef = ref(db, 'users/' + userId + '/username');
    try {
      const snapshot = await get(usernameRef);
      if (snapshot.exists()) {
        return snapshot.val();
      } else {
        console.error(`No username found for user ID: ${userId}`);
        return null;
      }
    } catch (error) {
      throw error;
    }
  }
  


  // Switch to real-time chat
  switchToRealtimeChatBtn.addEventListener('click', function () {
    onAuthStateChanged(auth, async (user) => {
      if (user) {
        const username = await getUsernameByUserId(user.uid);
        if (username) {
          console.log(`Switching to real-time chat for Username: ${username}`);
          document.querySelector('.container').style.display = 'none';
          realtimeChatContainer.style.display = 'block';
          switchToRealtimeChatBtn.style.display = 'none';

          // Clear the chat when switching to real-time chat
          clearChat();
        } else {
          console.log("Failed to fetch username.");
        }
      } else {
        console.log("No user is signed in. Cannot switch to real-time chat.");
      }
    });
  });

  function clearChat() {
    realtimeChatMessages.innerHTML = '';
  }

  // Switch back to chatbot
  switchToChatbotBtn.addEventListener('click', function () {
    document.querySelector('.container').style.display = 'block';
    realtimeChatContainer.style.display = 'none';
    switchToRealtimeChatBtn.style.display = 'block';
  });




// Function to handle the submission of selected symptoms
function submitSymptoms() {
  const checkboxes = document.querySelectorAll('.symptoms-section .form-check-input');
  const selectedSymptoms = Array.from(checkboxes)
      .filter(checkbox => checkbox.checked)
      .map(checkbox => checkbox.value);

  if (selectedSymptoms.length > 0) {
      const symptomsText = selectedSymptoms.join(', ');
      const userQuestion = `I am experiencing the following symptoms: ${symptomsText}. What could be the issue?`;
      Send(userQuestion);

      // Clear the checkboxes
      checkboxes.forEach(checkbox => checkbox.checked = false);
  } else {
      alert('Please select at least one symptom.');
  }
}


// Add event listener to the Submit button
document.getElementById('submitSymptoms').addEventListener('click', submitSymptoms);



// Function to generate a conversation ID based on the user's first message
function generateConversationId(userMessage) {
  // Replace spaces with underscores and remove any special characters
  const sanitizedMessage = userMessage.replace(/[^a-zA-Z0-9 ]/g, "");
  // Replace spaces with underscores
  const conversationId = sanitizedMessage.replace(/ /g, " ");
  return conversationId;
}



// Function to send a question to the OpenAI API and save the conversation with a custom ID
async function Send(question) {
  const sQuestion = question || document.getElementById("userInput").value;
  if (sQuestion === "") {
    alert("Type in your question!");
    document.getElementById("userInput").focus();
    return;
  }

  const user = auth.currentUser;
  if (!user) {
    console.error("User is not signed in.");
    return;
  }

  const chatMessagesDiv = document.getElementById("chatMessages");

  // Create and display user message with timestamp above
  const userMessageDiv = document.createElement("div");
  userMessageDiv.className = "user-message chat-message";
  const userTimestamp = new Date();
  userMessageDiv.innerHTML = `<div class="timestamp">${formatTimestamp(userTimestamp)}</div>${sQuestion}`;
  chatMessagesDiv.appendChild(userMessageDiv);
  userMessageDiv.classList.add("chat-message-visible");
  chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;

  try {
    const response = await fetch("https://api.openai.com/v1/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "text-davinci-003",
        prompt: "Your name is Denti-Bot and you are a professional dentist and always answer the user question based on the conversation you started with the user and also answer all one word message and if that message is start with a greetings, answer it with a greestings." + sQuestion,
        max_tokens: 150,
        temperature: 0.7,
      })
    });

    if (!response.ok) {
      throw new Error(`Error from OpenAI API: ${response.statusText}`);
    }

    const responseData = await response.json();
    const responseText = responseData.choices[0].text.trim();

    // Create and display bot message with timestamp above
    const botMessageDiv = document.createElement("div");
    botMessageDiv.className = "bot-message chat-message";
    const botTimestamp = new Date();
    botMessageDiv.innerHTML = `<div class="timestamp"><b>Denti-Bot:</b> ${formatTimestamp(botTimestamp)}</div>${responseText}`;
    chatMessagesDiv.appendChild(botMessageDiv);
    setTimeout(() => {
      botMessageDiv.classList.add("chat-message-visible");
    }, 10);

    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;

    // Check if a conversation ID exists, if not, generate a new one
    if (!currentConversationId) {
      currentConversationId = generateConversationId(sQuestion);
      appendConversationIdToHistory(currentConversationId); // Function to add the conversation ID to the chat history
    }

    const conversationRef = doc(db, "conversations", currentConversationId);
    const conversationDoc = await getDoc(conversationRef);

    const conversationData = {
      userMessage: sQuestion,
      botResponse: responseText,
      timestamp: new Date(),
      userId: user.uid
    };

    if (conversationDoc.exists()) {
      const existingData = conversationDoc.data();
      const updatedMessages = [...existingData.messages, conversationData];
      await setDoc(conversationRef, { messages: updatedMessages });
    } else {
      await setDoc(conversationRef, { messages: [conversationData] });
    }

  } catch (error) {
    console.error("Error in Send function:", error);
  }
}

document.getElementById('sendMessage').addEventListener('click', function() {
  Send();
  document.getElementById("userInput").value = ''; // Clear the input field
});

document.getElementById('userInput').addEventListener('keyup', function(event) {
  if (event.key === 'Enter') {
      Send();
      this.value = ''; // Clear the input field
  }
});



// Global variable to track the current conversation ID
let currentConversationId = null;


// Function to append a conversation ID and user ID to the chat-history
function appendConversationIdToHistory(conversationId) {
  const chatHistoryDiv = document.querySelector('.chat-history');
  const conversationElement = document.createElement('div');
  conversationElement.className = 'conversation-element';

  const checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.className = 'conversation-checkbox';
  checkbox.value = conversationId;

  const conversationButton = document.createElement('button');
  conversationButton.className = 'conversation-id-btn btn btn-primary btn-sm m-1';
  conversationButton.textContent = `${conversationId}`;
  conversationButton.setAttribute('data-conversation-id', conversationId);

  conversationButton.addEventListener('click', () => {
    handleConversationClick(conversationId);
  });

  conversationElement.appendChild(checkbox);
  conversationElement.appendChild(conversationButton);
  
  chatHistoryDiv.appendChild(conversationElement);
}



// Function to load and display existing conversations
async function loadExistingConversations() {
  const chatHistoryDiv = document.querySelector('.chat-history');
  chatHistoryDiv.innerHTML = ''; // Clear existing content

  const user = auth.currentUser;
  if (!user) {
    console.log("No user is signed in.");
    return;
  }

  console.log("Current user ID:", user.uid); // Debugging

  try {
    const querySnapshot = await getDocs(collection(db, "conversations"));
    querySnapshot.forEach((doc) => {
      const conversationId = doc.id;
      const messages = doc.data().messages;
      const userId = messages.length > 0 ? messages[0].userId : 'Unknown User';


      // Check if the conversation belongs to the current user
      if (userId === user.uid) {
        appendConversationIdToHistory(conversationId, userId);
      }
    });
  } catch (error) {
    console.error("Error fetching conversations:", error);
  }
}

onAuthStateChanged(auth, (user) => {
  if (user) {
    console.log("User is signed in, UID:", user.uid);
    loadExistingConversations(); // Call this function only after confirming the user is signed in
  } else {
    console.log("No user is signed in.");
    // Handle the case when no user is signed in
  }
});


document.getElementById('selectAllConversations').addEventListener('click', function() {
  const checkboxes = document.querySelectorAll('.conversation-checkbox');
  const areAllChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);

  checkboxes.forEach(checkbox => checkbox.checked = !areAllChecked);
});


document.getElementById('trashSelectedConversations').addEventListener('click', async function() {
  const selectedCheckboxes = document.querySelectorAll('.conversation-checkbox:checked');
  for (const checkbox of selectedCheckboxes) {
    const conversationId = checkbox.value;

    // Remove the checkbox
    checkbox.remove();

    // Delete the conversation from Firestore
    await deleteDoc(doc(db, "conversations", conversationId));

    // Remove the conversation button from the chat-history
    const conversationButton = document.querySelector(`button[data-conversation-id="${conversationId}"]`);
    if (conversationButton) {
      conversationButton.remove();
    }

    // Check if the deleted conversation is currently displayed and reset the chat if it is
    if (currentConversationId === conversationId) {
      startNewChat();
    }
  }
});


// Function to handle clicking on a conversation ID
async function handleConversationClick(conversationId) {
  currentConversationId = conversationId;
  const chatMessagesDiv = document.getElementById("chatMessages");
  chatMessagesDiv.innerHTML = ''; // Clear existing chat messages

  const conversationRef = doc(db, "conversations", conversationId);
  const conversationDoc = await getDoc(conversationRef);

  if (conversationDoc.exists()) {
    const conversationData = conversationDoc.data();
    const messages = conversationData.messages || [];

    messages.forEach(message => {
      // User message with timestamp above
      const userMessageDiv = document.createElement("div");
      userMessageDiv.className = "user-message";
      userMessageDiv.innerHTML = `<div class="timestamp">${formatTimestamp(new Date(message.timestamp.toDate()))}</div>${message.userMessage}`;
      chatMessagesDiv.appendChild(userMessageDiv);

      // Bot response with timestamp above
      const botResponseDiv = document.createElement("div");
      botResponseDiv.className = "bot-message";
      botResponseDiv.innerHTML = `<div class="timestamp"><b>Denti-Bot:</b> ${formatTimestamp(new Date(message.timestamp.toDate()))}</div>${message.botResponse}`;
      chatMessagesDiv.appendChild(botResponseDiv);
    });
  } else {
    console.log("No such conversation!");
    chatMessagesDiv.textContent = 'No conversation found.';
  }
}

// Function to start a new chat
function startNewChat() {
  currentConversationId = null;
  const chatMessagesDiv = document.getElementById("chatMessages");
  chatMessagesDiv.innerHTML = ""; // Clear the chat messages
  currentConversationId = null; // Reset the current conversation ID

  const welcomeMessageDiv = document.createElement("div");
  welcomeMessageDiv.className = "bot-message";
  welcomeMessageDiv.innerHTML = "Hello! Please Type your Symptoms in the Text Input.";
  chatMessagesDiv.appendChild(welcomeMessageDiv);

  document.getElementById("userInput").value = ""; // Clear the input field
}


// Attach the startNewChat function to the New Chat button
document.getElementById('newChat').addEventListener('click', startNewChat);



listenForAdminMessages();
loadPreviousMessages();




});

